﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Circles_Intersection
{
   public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }

    }
}
