﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Circles_Intersection
{
    public class Circle
    {
        public double Point { set; get; }
       
        public double Radius { set; get; }

    }
}
